
CREATE OR REPLACE PACKAGE PKG_CLIENTE AS
  FUNCTION FN_VALIDAR_EMAIL(p_email VARCHAR2) RETURN NUMBER;
  FUNCTION FN_NORMALIZAR_CEP(p_cep VARCHAR2) RETURN VARCHAR2;

  PROCEDURE PRC_INSERIR_CLIENTE (
    p_nome        IN  VARCHAR2,
    p_email       IN  VARCHAR2,
    p_cep         IN  VARCHAR2,
    p_logradouro  IN  VARCHAR2,
    p_bairro      IN  VARCHAR2,
    p_cidade      IN  VARCHAR2,
    p_uf          IN  VARCHAR2,
    p_ativo       IN  NUMBER,
    p_id_cliente  OUT NUMBER
  );

  PROCEDURE PRC_ATUALIZAR_CLIENTE (
    p_id_cliente  IN NUMBER,
    p_nome        IN VARCHAR2,
    p_email       IN VARCHAR2,
    p_cep         IN VARCHAR2,
    p_logradouro  IN VARCHAR2,
    p_bairro      IN VARCHAR2,
    p_cidade      IN VARCHAR2,
    p_uf          IN VARCHAR2,
    p_ativo       IN NUMBER
  );

  PROCEDURE PRC_DELETAR_CLIENTE(p_id NUMBER);

  PROCEDURE PRC_LISTAR_CLIENTES(
    p_nome   IN VARCHAR2,
    p_email  IN VARCHAR2,
    p_rc     OUT SYS_REFCURSOR
  );
END PKG_CLIENTE;
/
CREATE OR REPLACE PACKAGE BODY PKG_CLIENTE AS

FUNCTION FN_VALIDAR_EMAIL(p_email VARCHAR2) RETURN NUMBER IS
BEGIN
  IF REGEXP_LIKE(p_email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') THEN
    RETURN 1;
  END IF;
  RETURN 0;
END;

FUNCTION FN_NORMALIZAR_CEP(p_cep VARCHAR2) RETURN VARCHAR2 IS
  v_cep VARCHAR2(8);
BEGIN
  v_cep := REGEXP_REPLACE(p_cep, '[^0-9]', '');
  IF LENGTH(v_cep) <> 8 THEN
     RAISE_APPLICATION_ERROR(-20001, 'CEP inválido. Deve conter 8 dígitos.');
  END IF;
  RETURN v_cep;
END;

PROCEDURE VALIDAR_DADOS(
  p_nome  VARCHAR2,
  p_email VARCHAR2,
  p_cep   VARCHAR2,
  p_uf    VARCHAR2
) IS
BEGIN
  IF p_nome IS NULL THEN
     RAISE_APPLICATION_ERROR(-20001, 'Nome é obrigatório.');
  END IF;

  IF FN_VALIDAR_EMAIL(p_email) = 0 THEN
     RAISE_APPLICATION_ERROR(-20001, 'Email inválido.');
  END IF;

  IF p_cep IS NOT NULL THEN
     FN_NORMALIZAR_CEP(p_cep);
  END IF;

  IF p_uf IS NOT NULL AND p_uf NOT IN (
    'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA',
    'MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN',
    'RS','RO','RR','SC','SP','SE','TO'
  ) THEN
     RAISE_APPLICATION_ERROR(-20001, 'UF inválida.');
  END IF;
END;

PROCEDURE PRC_INSERIR_CLIENTE (
  p_nome        IN  VARCHAR2,
  p_email       IN  VARCHAR2,
  p_cep         IN  VARCHAR2,
  p_logradouro  IN  VARCHAR2,
  p_bairro      IN  VARCHAR2,
  p_cidade      IN  VARCHAR2,
  p_uf          IN  VARCHAR2,
  p_ativo       IN  NUMBER,
  p_id_cliente  OUT NUMBER
) IS
BEGIN
  VALIDAR_DADOS(p_nome, p_email, p_cep, p_uf);

  INSERT INTO TB_CLIENTE (
    NOME, EMAIL, CEP, LOGRADOURO, BAIRRO, CIDADE, UF, ATIVO
  ) VALUES (
    p_nome,
    p_email,
    CASE WHEN p_cep IS NOT NULL THEN FN_NORMALIZAR_CEP(p_cep) END,
    p_logradouro, p_bairro, p_cidade, p_uf, p_ativo
  )
  RETURNING ID_CLIENTE INTO p_id_cliente;

EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    RAISE_APPLICATION_ERROR(-20002, 'Email já cadastrado.');
END;

PROCEDURE PRC_ATUALIZAR_CLIENTE (
  p_id_cliente  IN NUMBER,
  p_nome        IN VARCHAR2,
  p_email       IN VARCHAR2,
  p_cep         IN VARCHAR2,
  p_logradouro  IN VARCHAR2,
  p_bairro      IN VARCHAR2,
  p_cidade      IN VARCHAR2,
  p_uf          IN VARCHAR2,
  p_ativo       IN NUMBER
) IS
BEGIN
  VALIDAR_DADOS(p_nome, p_email, p_cep, p_uf);

  UPDATE TB_CLIENTE
     SET NOME = p_nome,
         EMAIL = p_email,
         CEP = CASE WHEN p_cep IS NOT NULL THEN FN_NORMALIZAR_CEP(p_cep) END,
         LOGRADOURO = p_logradouro,
         BAIRRO = p_bairro,
         CIDADE = p_cidade,
         UF = p_uf,
         ATIVO = p_ativo,
         DT_ATUALIZACAO = SYSTIMESTAMP
   WHERE ID_CLIENTE = p_id_cliente;

  IF SQL%ROWCOUNT = 0 THEN
     RAISE_APPLICATION_ERROR(-20003, 'Cliente não encontrado.');
  END IF;
END;

PROCEDURE PRC_DELETAR_CLIENTE(p_id NUMBER) IS
BEGIN
  DELETE FROM TB_CLIENTE WHERE ID_CLIENTE = p_id;
  IF SQL%ROWCOUNT = 0 THEN
     RAISE_APPLICATION_ERROR(-20003, 'Cliente não encontrado.');
  END IF;
END;

PROCEDURE PRC_LISTAR_CLIENTES(
  p_nome   IN VARCHAR2,
  p_email  IN VARCHAR2,
  p_rc     OUT SYS_REFCURSOR
) IS
BEGIN
  OPEN p_rc FOR
    SELECT *
      FROM TB_CLIENTE
     WHERE (p_nome  IS NULL OR UPPER(NOME) LIKE '%'||UPPER(p_nome)||'%')
       AND (p_email IS NULL OR EMAIL = p_email)
     ORDER BY NOME;
END;

END PKG_CLIENTE;
/
